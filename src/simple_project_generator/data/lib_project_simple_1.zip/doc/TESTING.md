# {MODULE_NAME}

{SUMMARY}

## Test the package

```bash
cd src
python3 -m {MODULE_NAME}.program
```


