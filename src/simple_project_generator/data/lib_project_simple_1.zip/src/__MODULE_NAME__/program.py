import os
import sys

import {MODULE_NAME}.about as about
from {MODULE_NAME}.modules.wabout import show_about


# ----------------------------------------------------------
# Main CLI
# ----------------------------------------------------------

def main():
    show_about()


if __name__ == "__main__":
    main()

