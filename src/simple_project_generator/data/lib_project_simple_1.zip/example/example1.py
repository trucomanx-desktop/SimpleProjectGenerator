#!/usr/bin/python3

import sys
sys.path.append("../src")

import {MODULE_NAME}.about as about

print(about.__package__)
print(about.__version__)
